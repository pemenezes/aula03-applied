# this program needs to convert an colored image in a scale of gray

import cv2

'''
ABOVE, WE ARE IMPORTING THE LIBRARY OPENCV, WICH WILL HELP US IN THE IMAGE MANIPULATION 
'''

import matplotlib.pyplot as plt

'''
LIBRARY TO DISPLAY GRAPHICAL ELEMENTS
'''

#===== FUNCTION BLOCK TO MANIPULATE THE IMAGES =====#
'''
1st step: define the image that will be uploaded
'''

def load_image(path):

    image = cv2.imread(path) #reading the image

    if image is None:
        raise ValueError("Image not found")
    else:
        return image

'''
2nd step: define a function that will convert the image in a scale of gray
'''

def convert_gray(image):
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

'''
3rd step: define the function of the histogram
'''

def histograma(image):
    plt.hist(image.ravel(), bins=256, range= [0, 256])
    plt.title("Intensity histogram")
    plt.xlabel("Intensity")
    plt.ylabel("pixels quantity")
    plt.show()

#==============================
# Ajuste de brilho e contraste
#===============================

def ajuste_brilho_contrate(imagem, alpha=1.0,beta=0):
    '''
    alpha - controla o contraste da imagem
    beta - controla o brilho
    '''

    return cv2.convertScaleAbs(imagem, alpha = alpha, beta = beta)

#==============================
# Ajuste do histograma
#===============================

def equalizador_histograma(imagem):
    '''
    melhorar o contraste global redistribuido a intensidade dos pixels
    '''

    return cv2.equalizeHist(imagem)

def calcular_metricas(imagem):
    brilho = imagem.mean()
    contaste = imagem.std() # aqui a métricaa será observada a partir do desvio padrão

    return brilho, contaste




'''
4th step: define the function that shows the image
'''

def show_image(image, title="Image"):
    plt.imshow(image, cmap='gray') #imgshow = show the image
    plt.title(title)
    plt.axis("off")
    plt.show()

if __name__ == "__main__":
    img = load_image("goat.jpg")
    gray = convert_gray(img)
    show_image(gray, "Gray scale image")
    histograma(gray)

