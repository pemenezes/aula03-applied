#este é o arquivo principal da aplicação - entry point

#para executar as funções definidas no outro arquivo, precisamos importar os recursos
import cv2


from aula01 import(
    load_image,
    convert_gray,
    histograma,
    ajuste_brilho_contrate,
    equalizador_histograma,
    calcular_metricas
)



if __name__ == '__main__':

#===========================================
# carregar a imagem
#===========================================
    
    img = load_image(r'c:\Users\labsfiap\Desktop\aula3\APPLIED-COMPUTER-VISION---class-02\goat.jpg')
    print("Shape imagem colorida", img.shape)

#===========================================
# converte a imagem em cinza
#===========================================

    gray = convert_gray(img)
    print("Shape imagem gray scale")

    load_image(gray, "imagem original(gray)")
    histograma(gray)

    brilho, contraste = calcular_metricas(gray)
    print("\n............ MÉTRICAS ORIGINAIS.............")
    print("Brilho médio ", brilho)
    print("Contraste obtido através do desvio padrão:", contraste)

#===========================================
# ajuste de brilho e contraste
#===========================================

    ajuste = ajuste_brilho_contrate(gray, alpha = 1.3, beta = 30)
    load_image(ajuste, "brilho e contrastes ajustados")
    histograma(ajuste)

    brilho_aj, contrsate_aj = calcular_metricas(ajuste)
    print("\n............ MÉTRICAS APÓS OS AJUSTES.............")
    print("Brilho médio ", brilho_aj)
    print("Contraste obtido através do desvio padrão:", contrsate_aj)


#===========================================
# equalizando o histograma
#===========================================

    equalizar = equalizador_histograma(ajuste)
    load_image(equalizar , "imagem equalizaada, a partir do brilho e contraste")
    histograma(equalizar)


    brilho_eq, contrsate_eq = calcular_metricas(ajuste)
    print("\n............ MÉTRICAS APÓS EQUALIZAR.............")
    print("Brilho médio ", brilho_eq)
    print("Contraste obtido através do desvio padrão:", contrsate_eq)